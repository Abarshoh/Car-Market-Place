package uz.akbar.carea.model

data class User(var username: String, var password: String, var email: String)