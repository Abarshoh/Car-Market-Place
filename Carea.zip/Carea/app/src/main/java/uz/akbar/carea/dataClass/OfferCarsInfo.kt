package uz.akbar.carea.dataClass

data class OfferCarsInfo(
    var discount:String,
    var matn1:String,
    var matn2:String,
    var rasm:Int
)
