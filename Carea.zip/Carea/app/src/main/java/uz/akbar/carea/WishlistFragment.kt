package uz.akbar.carea

import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import uz.akbar.carea.adapters.CarsAdapter
import uz.akbar.carea.dataClass.CarsData
import uz.akbar.carea.databinding.FragmentWishlistBinding

class WishlistFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val binding = FragmentWishlistBinding.inflate(inflater,container,false)
        val shared = requireContext().getSharedPreferences("shared", Context.MODE_PRIVATE)
        val gson = Gson()

        var carsJson = shared.getString("cars",null)
        var cars = gson.fromJson<ArrayList<CarsData>>(carsJson, object :TypeToken<ArrayList<CarsData>>() {}.type)


        return binding.root
    }

}