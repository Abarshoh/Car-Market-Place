package uz.akbar.carea.dataClass

data class CarsData(
    var carrasm:Int,
    var carname:String,
    var carprice:String,
    var carreyting:String,
    var toifa:String,
    var status:Boolean
): java.io.Serializable